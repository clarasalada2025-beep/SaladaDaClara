# Salada de Frutas da Clara

Site estático pronto para publicar no GitHub Pages.

## Publicar no GitHub Pages
1. Entre no GitHub e abra o repositório do seu site.
2. Envie o arquivo `index.html` para a raiz do repositório (a página principal).
3. Vá em **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/(root)` e clique em **Save**.
6. Aguarde a publicação e abra o endereço mostrado em Settings → Pages.

Os botões do WhatsApp usam o número informado: +55 99 96490-742 (link internacional: 559996490742).
Confira os preços, tamanhos e horários antes de publicar, caso queira fazer alterações.
